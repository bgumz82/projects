// Type definitions for the project
/// <reference types="vi